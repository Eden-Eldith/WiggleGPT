# WiggleGPT - complete paper source, revision 2026.10.26

Author: P.C. O'Brien (ORCID 0009-0007-3961-1182), Independent Researcher.

Main file: `WiggleGPT_Paper_Synced.tex`

Keep the main file with the four research figures and the original crest:
- `pretrain_loss_chart.png`
- `wiggle_analysis.png`
- `finetune_loss_chart.png`
- `wiggle_finetune_analysis.png`
- `figures/obrien-crest.png` (preserve this subdirectory)

Compile three times with `pdflatex -interaction=nonstopmode -halt-on-error WiggleGPT_Paper_Synced.tex` so contents entries, citations and cross-references resolve. The original source uses the bbm indicator font; the delivered PDF was compiled with MiKTeX/pdflatex, which supplies that font. Packages: article, inputenc, fontenc, amsmath, amssymb, amsfonts, bbm, graphicx, booktabs, hyperref, xcolor, float, geometry, listings and caption.

The complete current published manuscript is preserved, including the full SmolTalk2 instruction-fine-tuning supplement and the credentialism appendix. The 26 October 2026 supervised-task-adaptation supplement is added with a small abstract, discussion, conclusion and acknowledgments update. All original table bodies and figure bytes are retained; three wide tables have fit-to-width wrappers only.

First published 25 November 2025. Revised 26 October 2026. The existing concept DOI is https://doi.org/10.5281/zenodo.17859012 . A new version DOI will be assigned by Zenodo after the author publishes the revision.

The current edition adds a dedicated title page using the author's unchanged COLM crest, followed by a clickable table of contents listing sections and subsections. The manuscript text and all numerical content are unchanged by this front-matter addition. The cover has no printed page number; the contents uses Roman numbering, and the manuscript starts at Arabic page 1.
